﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace StudentEvaluationSystem
{
    public partial class Form1 : Form
    {
        SqlConnection con = new SqlConnection("Data Source=localhost;Initial Catalog=ProjectB;Integrated Security=True;Connect Timeout=15;Encrypt=False;TrustServerCertificate=False");
        SqlCommand cmd;
        SqlDataAdapter adapt;
        //ID variable used in Updating and Deleting Record  
        int ID = 0; 
        public Form1()
        {
            InitializeComponent();
        }
          // Add students 
        private void btnAdd_Click(object sender, EventArgs e)
        {
          if (txtfname.Text != "" && txtlname.Text != "" && txtemail.Text != "" && txtRegNo.Text != "" && txtcon.Text != "")
            {
                cmd = new SqlCommand("insert into Student(FirstName,LastName,Contact,Email,RegistrationNumber,Status) values(@p1,@p2,@p3,@p4,@p5,@p6)", con);
                con.Open();
                cmd.Parameters.AddWithValue("@p1", txtfname.Text);
                cmd.Parameters.AddWithValue("@p2", txtlname.Text);
                cmd.Parameters.AddWithValue("@p3", txtcon.Text);
                cmd.Parameters.AddWithValue("@p4", txtemail.Text);
                cmd.Parameters.AddWithValue("@p5", txtRegNo.Text);
                cmd.Parameters.AddWithValue("@p6", combStatus.Text);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Record Inserted Successfully");
              // SHOW DATA IN GRIDVIEW
                con.Open();
                DataTable dt = new DataTable();
                adapt = new SqlDataAdapter("select * from Student", con);
                adapt.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();

            }
            else
            {
                MessageBox.Show("Please Provide Details!");
            }

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        // Add CLO
        private void btnCLO_Click(object sender, EventArgs e)
        {
            if (txtCLO.Text != "")
            {
                cmd = new SqlCommand("insert into CLO(Name,DateCreated,DateUpdated) values(@c1,@c2,@c3)", con);
                con.Open();
                cmd.Parameters.AddWithValue("@c1", txtCLO.Text);
                cmd.Parameters.AddWithValue("@c2", DateTime.Now);
                cmd.Parameters.AddWithValue("@c3", DateTime.Now);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Record Inserted Successfully");
                // add data in gridview
                con.Open();
                DataTable dt = new DataTable();
                adapt = new SqlDataAdapter("select * from CLO", con);
                adapt.Fill(dt);
                gvClo.DataSource = dt;
                con.Close();
            }
            else
            {
                MessageBox.Show("Please Provide Details!");
            }
        }

        private void btnRubric_Click(object sender, EventArgs e)
        {
            if (txtRub.Text != "")
            {
                cmd = new SqlCommand("insert into Rubric(Details,CloId) values(@c1,@c2)", con);
                con.Open();
                cmd.Parameters.AddWithValue("@c1", txtRub.Text);
                cmd.Parameters.AddWithValue("@c2", cmbCloR.Text);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Record Inserted Successfully");
                // add data in gridview
                con.Open();
                DataTable dt = new DataTable();
                adapt = new SqlDataAdapter("select * from Rubric", con);
                adapt.Fill(dt);
                gvRub.DataSource = dt;
                con.Close();
            }
            else
            {
                MessageBox.Show("Please Provide Details!");
            }
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand sc = new SqlCommand("Select Id, CloId from Rubric", con);
            SqlDataReader reader;

            reader = sc.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("Id", typeof(string));
            dt.Columns.Add("CloId", typeof(string));
            dt.Load(reader);

            cmbCloR.DisplayMember = "CloId";
             cmbCloR.ValueMember = "Id"; cmbCloR.DataSource = dt;

            con.Close();
        

        }

        private void cmbCloR_SelectedIndexChanged(object sender, EventArgs e)
        {
            string ID = cmbCloR.SelectedValue.ToString();
        }
    }
}
